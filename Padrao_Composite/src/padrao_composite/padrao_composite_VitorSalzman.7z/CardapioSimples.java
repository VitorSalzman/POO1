/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package padrao_composite;

import java.util.ArrayList;

/**
 *
 * @author 20161BSI0403
 */
public class CardapioSimples implements Cardapio{
    private String item;
    
    

    @Override
    public String getItem() {
        return item;
    }

}
